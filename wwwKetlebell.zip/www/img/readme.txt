link incon crossfit



https://thenounproject.com/term/crossfit/ 

https://www.iconfinder.com/icons/682357/crossfit_fitness_gymnastics_gymnist_hang_rings_set_icon



verde SELVA: #379742